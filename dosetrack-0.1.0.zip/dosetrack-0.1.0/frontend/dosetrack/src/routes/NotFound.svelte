<script>
  import Section from "../components/Section.svelte";
</script>

<Section title="No tiene acceso a esto">
  <p>Si necesita acceso, por favor pida ayuda.</p>
</Section>
