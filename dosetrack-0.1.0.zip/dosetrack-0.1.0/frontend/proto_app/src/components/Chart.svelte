<script>
  export let width = 900;
  export let height = 380;
</script>

<canvas class="my-4 w-100" id="myChart" {width} {height} />
