<div class="flex-shrink-0 dropdown">
  <a
    href="?"
    class="d-block link-dark text-decoration-none text-white-50 me-2 dropdown-toggle"
    id="dropdownUser2"
    data-bs-toggle="dropdown"
    aria-expanded="true"
  >
    <img
      src="https://github.com/mdo.png"
      alt="mdo"
      width="32"
      height="32"
      class="rounded-circle"
    />
  </a>
  <ul
    class="dropdown-menu text-small shadow"
    aria-labelledby="dropdownUser2"
    style="position: absolute; inset: 0px 0px auto auto; margin: 0px; transform: translate(0px, 34px);"
    data-popper-placement="bottom-end"
  >
    <li><a class="dropdown-item" href="?">My profile</a></li>
    <li><a class="dropdown-item" href="?">My Company</a></li>
    <li><hr class="dropdown-divider" /></li>
    <li><a class="dropdown-item" href="?">Sign out</a></li>
  </ul>
</div>
