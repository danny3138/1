const API_URL = process.env.API_SERVER_URL //"http:\\\\localhost:8000"
//const API_URL = "https://888d-170-51-107-73.ngrok.io"

export default API_URL

